
var delay = 1000;
var intervalId = setInterval("playWhenReady()", delay);
var intervalId2 = setInterval("playWhenReady2()", delay);
var intervalId3 = setInterval("playWhenReady3()", delay);
var intervalId4 = setInterval("playWhenReady4()", delay);


function playWhenReady()
{
    var d = new Date();
    var h = d.getHours();
    var m = d.getMinutes(); 

    if 	(h === 6 && m === 0)
    {
       	let url = chrome.runtime.getURL('bells_morning.mp3')
		console.log(url)

		let a = new Audio(url)
		a.play()
        clearInterval(intervalId);              
    } 
};

function playWhenReady2()
{
    var d = new Date();
    var h = d.getHours();
    var m = d.getMinutes(); 

    if 	(h === 12 && m === 0)
    {
       	let url = chrome.runtime.getURL('bells_noon.mp3')
		console.log(url)

		let a = new Audio(url)
		a.play()
        clearInterval(intervalId2);              
    } 
};

function playWhenReady3()
{
    var d = new Date();
    var h = d.getHours();
    var m = d.getMinutes(); 

    if 	(h === 18 && m === 0)
    {
       	let url = chrome.runtime.getURL('bells_night.mp3')
		console.log(url)

		let a = new Audio(url)
		a.play()
        clearInterval(intervalId3);              
    } 
};

function playWhenReady4()
{
    var d = new Date();
    var h = d.getHours();
    var m = d.getMinutes(); 

    if  (h === 0 && m === 0)
    {
        let url = chrome.runtime.getURL('bells_midnight.mp3')
        console.log(url)

        let a = new Audio(url)
        a.play()
        clearInterval(intervalId3);              
    } 
};




