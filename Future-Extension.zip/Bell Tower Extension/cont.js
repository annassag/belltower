
var delay = 1000;
var intervalId = setInterval("playWhenReady()", delay);
// var intervalId2 = setInterval("playWhenReady2()", delay);
// var intervalId3 = setInterval("playWhenReady3()", delay);


function playWhenReady()
{
    var d = new Date();
    var h = d.getHours();
    var m = d.getMinutes(); 

    if 	(h === 15 && m === 0)
    {
       	let url = chrome.runtime.getURL('bells.mp3')
		console.log(url)

		let a = new Audio(url)
		a.play()
        clearInterval(intervalId);              
    } 
};

// function playWhenReady2()
// {
//     var d = new Date();
//     var h = d.getHours();
//     var m = d.getMinutes(); 

//     if 	(h === 19 && m === 14)
//     {
//        	let url = chrome.runtime.getURL('note.mp3')
// 		console.log(url)

// 		let a = new Audio(url)
// 		a.play()
//         clearInterval(intervalId2);              
//     } 
// };

// function playWhenReady3()
// {
//     var d = new Date();
//     var h = d.getHours();
//     var m = d.getMinutes(); 

//     if 	(h === 19 && m === 15)
//     {
//        	let url = chrome.runtime.getURL('ding.mp3')
// 		console.log(url)

// 		let a = new Audio(url)
// 		a.play()
//         clearInterval(intervalId3);              
//     } 
// };





